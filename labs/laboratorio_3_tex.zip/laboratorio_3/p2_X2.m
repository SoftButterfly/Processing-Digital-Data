function f = p2_X2( t )
    f = p2_X1( t ) + p2_X1( t-1 );
end

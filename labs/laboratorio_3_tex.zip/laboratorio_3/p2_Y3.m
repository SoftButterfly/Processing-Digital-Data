function f = p2_Y3( t )
    f = p2_Y1(t) - p2_Y1(t-2);
end

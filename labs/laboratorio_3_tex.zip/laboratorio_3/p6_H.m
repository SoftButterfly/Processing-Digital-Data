function f = p3_H( n )
    f = escalon(n)-escalon(n-8);
end

function f = triangle(t)
    f = gate(t/2).*(1-abs(t));
end

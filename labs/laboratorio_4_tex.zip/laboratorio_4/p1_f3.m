function f = p1_f3(t)
    f = triangle(t)+triangle(t-1)+triangle(t-2);
end

function f = p1_f2(t)
    f = 5*gate(t - 1) - gate(t + 1);
end

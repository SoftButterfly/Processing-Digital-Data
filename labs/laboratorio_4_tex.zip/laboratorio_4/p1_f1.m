function f = p1_f1(t)
    f = gate(0.5*t) + gate(t);
end

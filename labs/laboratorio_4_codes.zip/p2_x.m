function f = p2_x(t)
  f = -triangle(t+1)-triangle(t)+triangle(t-2);
end

Fs = 100;
T  = 1/Fs;
t = 0:T:8*pi;
y = p4_y(t);
plot(t, y)

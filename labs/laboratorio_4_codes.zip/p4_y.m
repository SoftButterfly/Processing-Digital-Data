function f = p4_y(t)
    f = sin(t) + 0.25*sin(10*t);
end

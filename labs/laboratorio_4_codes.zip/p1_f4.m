function f = p1_f4(t)
    f = -triangle(t)+triangle(t-2);
end

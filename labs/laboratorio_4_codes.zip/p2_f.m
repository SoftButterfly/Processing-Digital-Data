function f = p2_f(t)
  f = -triangle(0.5*(t+1))-triangle(0.5*(t))+triangle(0.5*(t-2));
end

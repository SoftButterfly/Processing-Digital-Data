function f = p2_Y2( t )
    f = p2_Y1(t) + p2_Y1(t-1);
end

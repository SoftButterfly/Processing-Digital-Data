function f = p1_H( n )
    f = 2*impulso(n+1) + 2*impulso(n-1);
end

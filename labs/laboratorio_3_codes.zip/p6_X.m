function f = p6_X( n )
    f = ((-1).^n).*(escalon(n)-escalon(-n-8));
end

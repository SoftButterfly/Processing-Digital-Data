function f = p2_X3( t )
    f = p2_X1( t ) - p2_X1( t-2 );
end

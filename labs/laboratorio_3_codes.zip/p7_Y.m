function f = p7_Y( n )
    f = ((0.25).^(n-1)).*escalon(n-1);
end
